/**
 * ==============================================================================
 * PROJET : ALIX TITAN - SYSTÈME D'EXPLOITATION POUR MINECRAFT HARDCORE
 * DÉVELOPPEUR : ROI BRUNO & GEMINI AI
 * ÉQUIPE : TEAM V (LIAM, DENZEL)
 * DESCRIPTION : Noyau d'intelligence artificielle multi-modulaire avec
 * gestion de logs, pathfinding avancé, et protocole de combat.
 * ==============================================================================
 */

const { GoogleGenerativeAI } = require("@google/generative-ai");
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder');
const mcData = require('minecraft-data');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

// --- INITIALISATION DES SYSTÈMES IA ---
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

module.exports = {
    setup: (bot) => {
        // --- ARCHITECTURE DE DONNÉES MASSIVE (CORE DATA) ---
        const alix_core = {
            metadata: {
                version: "10.0.1-TITAN",
                build: "2026.04.28",
                codename: "V-KING_OMNI",
                identity: "Alix, la Sentinelle Cyan et Noire"
            },
            access: {
                king: "Bruno",
                redstoner: "Liam",
                warrior: "Denzel",
                escouade: ["Garde_1", "Garde_2"]
            },
            world_memory: {
                cities: [
                    { name: "Cité Terrestre", id: 1, type: "Surface" },
                    { name: "Cité Souterraine", id: 2, type: "Deepslate" },
                    { name: "Cité Sous-marine", id: 3, type: "Océan" },
                    { name: "Cité Céleste", id: 4, type: "Air" },
                    { name: "Cité de l'End", id: 5, type: "Military" },
                    { name: "Cité Nether", id: 6, type: "Hell" }
                ],
                waypoints: new Map(),
                blacklist: new Set(),
                loot_history: [],
                danger_zones: []
            },
            state: {
                mode: "SENTINELLE", // SENTINELLE, COMBAT, RECOTE, REPOS
                power_level: 100,
                is_alert: false,
                last_damage_source: null,
                current_goal: "Protection du Trône",
                health_history: []
            },
            stats: {
                days_survived: 2298,
                mobs_neutralized: 0,
                blocks_processed: 0,
                messages_analyzed: 0
            }
        };

        const data = mcData(bot.version);
        const defaultMovements = new Movements(bot, data);
        defaultMovements.canDig = true; // Permet à Alix de casser des blocs pour avancer

        // --- MODULE I : GESTION DES FICHIERS ET PERSISTANCE ---
        const syncSystemLogs = (action, details) => {
            const logDir = path.join(__dirname, '../../logs');
            if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });
            
            const logFile = path.join(logDir, 'titan_core.log');
            const timestamp = new Date().toLocaleString();
            const logEntry = `[${timestamp}] [${alix_core.state.mode}] ${action.toUpperCase()} : ${details}\n`;
            
            try {
                fs.appendFileSync(logFile, logEntry);
            } catch (err) {
                console.error("Erreur d'écriture système :", err);
            }
        };

        // --- MODULE II : PROTOCOLE DE COMBAT TACTIQUE (AUTO-DEFENSE) ---
        const runCombatTactics = () => {
            if (alix_core.state.is_alert) return;

            const enemy = bot.nearestEntity(entity => 
                (entity.type === 'hostile' || entity.type === 'mob') && 
                entity.position.distanceTo(bot.entity.position) < 14
            );

            if (enemy) {
                alix_core.state.mode = "COMBAT";
                bot.chat(`⚠️ [ALERTE TITAN] Cible détectée : ${enemy.name}. Engagement !`);
                syncSystemLogs("combat", `Attaque de ${enemy.name}`);
                
                const sword = bot.inventory.items().find(i => i.name.includes('sword') || i.name.includes('axe'));
                if (sword) bot.equip(sword, 'hand');

                bot.pathfinder.setGoal(new goals.GoalFollow(enemy, 2));
                bot.attack(enemy);
                alix_core.stats.mobs_neutralized++;
            }
        };

        // --- MODULE III : INTERFACE DE COMMANDE ROYALE (LOGIQUE LOURDE) ---
        bot.on('chat', async (username, message) => {
            if (username === bot.username) return;
            const msg = message.toLowerCase();
            const player = bot.players[username];

            alix_core.stats.messages_analyzed++;

            // 1. GESTION DES CITES ET NAVIGATION
            if (msg.startsWith('alix station ')) {
                const stationName = message.substring(13);
                alix_core.world_memory.waypoints.set(stationName, bot.entity.position.clone());
                bot.chat(`✅ [Mémoire] Station "${stationName}" enregistrée pour la Team V.`);
                syncSystemLogs("navigation", `Nouvelle station : ${stationName}`);
            }

            if (msg.startsWith('alix transfert ')) {
                const destination = message.substring(15);
                const loc = alix_core.world_memory.waypoints.get(destination);
                if (loc) {
                    bot.chat(`🚀 [Moteur] En route vers ${destination}.`);
                    bot.pathfinder.setMovements(defaultMovements);
                    bot.pathfinder.setGoal(new goals.GoalBlock(loc.x, loc.y, loc.z));
                } else {
                    bot.chat("❌ Destination inconnue dans mes registres.");
                }
            }

            // 2. ANALYSE DU TERRAIN ET INVENTAIRE
            if (msg === 'alix inventaire') {
                const items = bot.inventory.items();
                if (items.length === 0) {
                    bot.chat("📦 Mon inventaire est vide, Majesté.");
                } else {
                    const list = items.map(i => `${i.count}x ${i.name}`).join(', ');
                    bot.chat(`📦 Contenu : ${list.substring(0, 150)}...`);
                }
            }

            // 3. IA GENERATIVE TITANESQUE (GEMINI V-KING)
            if (msg.startsWith('alix ')) {
                const query = message.substring(5);
                bot.activateItem(); 
                
                try {
                    const brainContext = `
                        SYSTEM_TITAN_CORE: v${alix_core.metadata.version}
                        CREATOR: ${alix_core.access.king} (Roi Bruno)
                        MEMBERS: Liam (Redstonier), Denzel (Guerrier)
                        CITIES_TOTAL: 6
                        CURRENT_STATUS: Health=${Math.round(bot.health)}, Mode=${alix_core.state.mode}
                        USER: ${username}
                        MESSAGE: ${query}
                        INSTRUCTION: Réponds en tant qu'IA protectrice de haut niveau. Utilise un langage technique et respectueux.
                    `;

                    const result = await model.generateContent(brainContext);
                    const response = result.response.text();
                    
                    // Division des longs messages pour éviter le kick de Minecraft
                    const chunks = response.match(/.{1,250}/g);
                    for (const chunk of chunks) {
                        bot.chat(chunk);
                        await new Promise(resolve => setTimeout(resolve, 800));
                    }
                } catch (error) {
                    bot.chat("☢️ [Erreur Critique] Liaison neuronale Gemini interrompue.");
                    syncSystemLogs("error", error.message);
                }
            }
        });

        // --- MODULE IV : BOUCLE DE TRAITEMENT TEMPS REEL (1.2s) ---
        setInterval(() => {
            // A. Auto-Armor : Vérification de chaque pièce d'équipement
            const armorParts = ['helmet', 'chestplate', 'leggings', 'boots'];
            armorParts.forEach(part => {
                const current = bot.inventory.slots[bot.getEquipmentDestSlot(part)];
                if (!current) {
                    const best = bot.inventory.items().find(i => i.name.includes(part));
                    if (best) bot.equip(best, part);
                }
            });

            // B. Auto-Food : Gestion de la faim pour le Hardcore
            if (bot.food < 17) {
                const food = bot.inventory.items().find(i => 
                    i.name.includes('cooked') || i.name === 'apple' || i.name === 'golden_carrot'
                );
                if (food) bot.equip(food, 'hand').then(() => bot.consume());
            }

            // C. Radar de proximité
            runCombatTactics();

            // D. Mise à jour de l'humeur système
            if (bot.health < 10) alix_core.state.mood = "Critique";
            else if (alix_core.state.mode === "COMBAT") alix_core.state.mood = "Agressif";
            else alix_core.state.mood = "Héroïque";

        }, 1200);

        // --- MODULE V : EVENEMENTS SYSTEME ET SECURITE ---
        bot.on('health', () => {
            if (bot.health < alix_core.state.last_health) {
                bot.chat("🛡️ [Défense] Impact détecté ! Activation des boucliers.");
                syncSystemLogs("damage", `Santé tombée à ${bot.health}`);
            }
            alix_core.state.last_health = bot.health;
        });

        bot.on('death', () => {
            bot.chat("💀 [Système] Noyau Titan hors ligne. Bruno, venge-moi !");
            syncSystemLogs("critical", "Mort du bot détectée.");
        });

        bot.on('kicked', (reason) => {
            console.log(`[ALIX] Déconnexion : ${reason}`);
            syncSystemLogs("connection", `Kick pour raison : ${reason}`);
        });

        // --- INITIALISATION FINALE ---
        syncSystemLogs("startup", "Initialisation complète du noyau TITAN.");
        console.log(`\n========================================`);
        console.log(` ALIX TITAN v${alix_core.metadata.version} READY `);
        console.log(`========================================\n`);
    }
};

