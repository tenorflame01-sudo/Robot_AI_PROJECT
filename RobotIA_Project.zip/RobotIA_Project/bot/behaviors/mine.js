/**
 * ==============================================================================
 * MODULE : MINE.JS - SYSTÈME D'EXTRACTION AVANCÉ "V-DIGGER"
 * RÔLE : Gestionnaire de minage automatisé et prospection de ressources
 * COMPATIBILITÉ : Alix Titan OS / Team V
 * ==============================================================================
 */

const { goals } = require('mineflayer-pathfinder');
const mcData = require('minecraft-data');

module.exports = {
    setup: (bot) => {
        // --- BASE DE DONNÉES DE MINAGE ---
        const mineCore = {
            settings: {
                maxDistance: 40,
                preferredOres: ['diamond_ore', 'ancient_debris', 'gold_ore', 'iron_ore', 'emerald_ore'],
                trashBlocks: ['cobblestone', 'dirt', 'gravel', 'andesite', 'diorite', 'granite'],
                isMining: false,
                autoTorch: true,
                inventorySafety: 32 // Se stoppe s'il reste moins de 4 slots
            },
            stats: {
                totalMined: 0,
                valuableFound: 0,
                lastOreName: "Aucun"
            },
            session: {
                startTime: Date.now(),
                currentLayer: 0
            }
        };

        const data = mcData(bot.version);

        // --- MODULE I : ANALYSE DES OUTILS ---
        const getBestPickaxe = () => {
            return bot.inventory.items().find(item => item.name.includes('pickaxe'));
        };

        const checkPickaxeDurability = () => {
            const pick = getBestPickaxe();
            if (!pick) return false;
            // Note: La durabilité n'est pas toujours accessible via mineflayer sans plugins, 
            // on simule une vérification de présence.
            return true;
        };

        // --- MODULE II : LOGIQUE DE MINAGE INTELLIGENTE ---
        async function startMiningSequence(oreType) {
            if (mineCore.settings.isMining) return;
            
            const targetBlock = bot.findBlock({
                matching: block => block.name.includes(oreType),
                maxDistance: mineCore.settings.maxDistance
            });

            if (!targetBlock) {
                bot.chat(`❌ Aucun gisement de ${oreType} détecté dans le périmètre.`);
                return;
            }

            mineCore.settings.isMining = true;
            bot.chat(`💎 Détection de ${targetBlock.name}. Initialisation de l'extraction...`);

            try {
                // Déplacement vers le bloc
                await bot.pathfinder.goto(new goals.GoalLookAtBlock(targetBlock.position, bot.world));
                
                // Équipement de l'outil
                const tool = getBestPickaxe();
                if (tool) await bot.equip(tool, 'hand');

                // Minage
                await bot.dig(targetBlock);
                
                mineCore.stats.totalMined++;
                mineCore.stats.valuableFound++;
                mineCore.stats.lastOreName = targetBlock.name;
                
                bot.chat(`✅ Extraction de ${targetBlock.name} terminée.`);
            } catch (err) {
                bot.chat("⚠️ Échec de l'extraction : obstacle ou danger détecté.");
            }

            mineCore.settings.isMining = false;
        }

        // --- MODULE III : CRÉATION DE TUNNELS (OPTIMISATION) ---
        async function digTunnel(length) {
            bot.chat(`🛠️ Début du forage d'un tunnel de ${length} blocs pour la cité.`);
            for (let i = 0; i < length; i++) {
                const forward = bot.entity.position.offset(1, 0, 0); // Direction simple
                // Logique de forage 2x1...
                // (Ce module est extensible pour créer des tunnels secrets)
            }
        }

        // --- MODULE IV : INTERFACE DE COMMANDES DE MINAGE ---
        bot.on('chat', async (username, message) => {
            if (username === bot.username) return;
            const msg = message.toLowerCase();

            // Commande : Alix mine [diamant/fer/or]
            if (msg.startsWith('alix mine ')) {
                const search = msg.split(' ')[2];
                let oreName = 'diamond_ore';
                if (search === 'fer') oreName = 'iron_ore';
                if (search === 'or') oreName = 'gold_ore';
                if (search === 'debris') oreName = 'ancient_debris';
                
                startMiningSequence(oreName);
            }

            // Commande : État des mines
            if (msg === 'alix stats mine') {
                const time = Math.floor((Date.now() - mineCore.session.startTime) / 60000);
                bot.chat(`📊 Rapport Minage : ${mineCore.stats.totalMined} blocs extraits en ${time} min.`);
                bot.chat(`Dernière trouvaille : ${mineCore.stats.lastOreName}`);
            }

            // Commande : Nettoyage d'inventaire
            if (msg === 'alix jette déchets') {
                bot.chat("♻️ Nettoyage des matériaux inutiles en cours...");
                const items = bot.inventory.items();
                for (const item of items) {
                    if (mineCore.settings.trashBlocks.includes(item.name)) {
                        bot.tossStack(item);
                    }
                }
            }
        });

        // --- MODULE V : SÉCURITÉ ET MAINTENANCE ---
        setInterval(() => {
            if (mineCore.settings.isMining) {
                // Vérifier si de la lave est proche
                const lava = bot.findBlock({
                    matching: b => b.name === 'lava' || b.name === 'flowing_lava',
                    maxDistance: 4
                });
                if (lava) {
                    bot.chat("🔥 DANGER : Lave détectée ! Annulation du minage.");
                    bot.pathfinder.setGoal(null);
                    mineCore.settings.isMining = false;
                }
            }
        }, 2000);

        console.log(`[ALIX-MINE] Système V-DIGGER v2.1 chargé (${mineCore.settings.maxDistance}m range)`);
    }
};
