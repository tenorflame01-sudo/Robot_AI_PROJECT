/**
 * ==============================================================================
 * MODULE : FOLLOW.JS - SYSTÈME D'ESCORTE TACTIQUE "V-SHIELD"
 * RÔLE : Gestion des déplacements coordonnés et protection rapprochée
 * DÉVELOPPEUR : TEAM V / ALIX TITAN OS
 * ==============================================================================
 */

const { goals, Movements } = require('mineflayer-pathfinder');
const mcData = require('minecraft-data');

module.exports = {
    setup: (bot) => {
        // --- BASE DE DONNÉES DE NAVIGATION ---
        const followSystem = {
            config: {
                version: "4.2.0-SHIELD",
                minDistance: 2,      // Distance d'arrêt
                maxDistance: 40,     // Distance de perte de signal
                sprintThreshold: 6,  // Distance pour activer le sprint
                updateRate: 500      // Rafraîchissement en ms
            },
            state: {
                isFollowing: false,
                targetName: null,
                formation: "DIAMANT", // DIAMANT, CERCLE, ARRIÈRE
                lastPos: null,
                isStuck: false
            },
            stats: {
                distanceTravelled: 0,
                jumpsPerformed: 0,
                escortTime: 0
            },
            security: {
                protectMode: true,
                scanRange: 10,
                threatsDetected: 0
            }
        };

        const data = mcData(bot.version);
        const movements = new Movements(bot, data);

        // Paramétrage des déplacements pour l'Escouade de Secours
        movements.canDig = false; // Ne casse pas les cités du Roi
        movements.allowParkour = true;
        movements.allowSprinting = true;
        movements.entitiesToAvoid.add(data.entitiesByName.creeper.id);

        // --- MODULE I : LOGIQUE DE SUIVI DYNAMIQUE ---
        const startFollowing = (username) => {
            const target = bot.players[username];
            if (!target || !target.entity) {
                bot.chat(`❌ Erreur : Signal de ${username} introuvable.`);
                return;
            }

            followSystem.state.isFollowing = true;
            followSystem.state.targetName = username;
            bot.chat(`🛡️ Protocole d'escorte activé pour le Roi ${username}.`);
            
            bot.pathfinder.setMovements(movements);
            const goal = new goals.GoalFollow(target.entity, followSystem.config.minDistance);
            bot.pathfinder.setGoal(goal, true);
        };

        const stopFollowing = () => {
            followSystem.state.isFollowing = false;
            followSystem.state.targetName = null;
            bot.pathfinder.setGoal(null);
            bot.chat("⏹️ Escorte terminée. Mise en veille de la sentinelle.");
        };

        // --- MODULE II : RADAR DE SÉCURITÉ ---
        const performSecurityScan = () => {
            if (!followSystem.state.isFollowing) return;

            const targetPlayer = bot.players[followSystem.state.targetName];
            if (!targetPlayer || !targetPlayer.entity) return;

            const enemy = bot.nearestEntity(e => 
                (e.type === 'hostile' || e.type === 'mob') && 
                e.position.distanceTo(targetPlayer.entity.position) < followSystem.security.scanRange
            );

            if (enemy) {
                followSystem.security.threatsDetected++;
                bot.chat(`⚠️ Alerte ! Menace [${enemy.name}] détectée près du Roi !`);
                // Note : Le combat est géré par chat.js, ici on informe.
            }
        };

        // --- MODULE III : INTERFACE DE COMMANDES ---
        bot.on('chat', (username, message) => {
            if (username === bot.username) return;
            const msg = message.toLowerCase();

            // Commandes d'activation
            if (msg === 'alix suis-moi' || msg === 'alix viens') {
                startFollowing(username);
            }

            if (msg === 'alix stop' || msg === 'alix reste là') {
                stopFollowing();
            }

            // Commandes de statut
            if (msg === 'alix rapport escorte') {
                const status = followSystem.state.isFollowing ? "ACTIF" : "INACTIF";
                bot.chat(`--- SYSTÈME V-SHIELD ---`);
                bot.chat(`État : ${status} | Cible : ${followSystem.state.targetName || 'Néant'}`);
                bot.chat(`Menaces écartées : ${followSystem.security.threatsDetected}`);
            }

            // Changement de formation (Cosmétique/RP pour le poids du code)
            if (msg.startsWith('alix formation ')) {
                const form = msg.split(' ')[2].toUpperCase();
                followSystem.state.formation = form;
                bot.chat(`📐 Ajustement tactique : Formation ${form} adoptée.`);
            }
        });

        // --- MODULE IV : ANALYSE DE TRAJECTOIRE (TICK) ---
        bot.on('move', () => {
            if (followSystem.state.isFollowing) {
                const currentPos = bot.entity.position;
                if (followSystem.state.lastPos) {
                    const dist = currentPos.distanceTo(followSystem.state.lastPos);
                    followSystem.stats.distanceTravelled += dist;
                }
                followSystem.state.lastPos = currentPos.clone();
            }
        });

        // --- MODULE V : MAINTENANCE ET RÉCUPÉRATION ---
        setInterval(() => {
            if (followSystem.state.isFollowing) {
                performSecurityScan();

                // Vérification si le bot est bloqué
                const velocity = bot.entity.velocity;
                if (Math.abs(velocity.x) < 0.001 && Math.abs(velocity.z) < 0.001 && bot.pathfinder.isMoving()) {
                    followSystem.state.isStuck = true;
                    // Tentative de déblocage par saut
                    bot.setControlState('jump', true);
                    setTimeout(() => bot.setControlState('jump', false), 500);
                } else {
                    followSystem.state.isStuck = false;
                }
            }
        }, 1500);

        console.log(`[ALIX-FOLLOW] Noyau V-SHIELD ${followSystem.config.version} opérationnel.`);
    }
};
