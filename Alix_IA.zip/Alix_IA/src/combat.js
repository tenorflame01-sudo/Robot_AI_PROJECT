module.exports = (bot) => {
  bot.on('entityHurt', (entity) => {
    // Si Alix se fait attaquer
    if (entity === bot.entity) {
      const attacker = bot.nearestEntity(e => e.type === 'mob' || e.type === 'player');
      if (attacker) {
        bot.chat("Alerte ! On m'attaque, je me défends !");
        bot.attack(attacker);
      }
    }
  });
};
