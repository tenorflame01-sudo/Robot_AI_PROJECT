module.exports = (bot) => {
  bot.finishGame = async () => {
    bot.chat("👑 Initialisation du Protocole Royal : Fin du Jeu.");
    
    // Liste des grandes étapes
    const steps = [
      "1. Collecte de bois et fabrication d'outils en pierre.",
      "2. Minage de fer et fabrication d'une armure complète.",
      "3. Recherche de diamants et d'obsidienne.",
      "4. Entrée dans le Nether pour les bâtons de Blaze.",
      "5. Chasse aux Endermen pour les perles.",
      "6. Localisation du Stronghold via les Yeux de l'End.",
      "7. Combat final contre l'Ender Dragon."
    ];

    for (const step of steps) {
      bot.chat(step);
      // On laisse un petit délai entre chaque annonce
      await new Promise(res => setTimeout(res, 2000));
    }

    bot.chat("Je commence l'étape 1 immédiatement !");
    // Ici, on pourrait ajouter bot.mineBlock('log') pour commencer vraiment
  };
};

