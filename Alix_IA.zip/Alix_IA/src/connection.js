const mineflayer = require('mineflayer');
const config = require('../config');

function createAlix() {
  const bot = mineflayer.createBot({
    host: config.host,
    port: config.port,
    username: config.username,
    version: config.version,
    offline: true
  });

  bot.on('spawn', () => {
    console.log("Alix a rejoint le monde !");
  });

  bot.on('error', (err) => {
    console.log("Erreur de connexion :", err);
  });

  return bot;
}

module.exports = { createAlix };
