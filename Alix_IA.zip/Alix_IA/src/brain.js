const { GoogleGenerativeAI } = require("@google/generative-ai");
const fs = require('fs');
const path = require('path');
require('dotenv').config();

// --- CONFIGURATION DE L'IA ---
const genAI = new GoogleGenerativeAI(process.env.GEMINI_KEY);
const aiModel = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

// --- GESTION DE LA MÉMOIRE ---
const memoryPath = path.join(__dirname, '../data/memory.json');

function loadMemory() {
    try {
        return JSON.parse(fs.readFileSync(memoryPath, 'utf8'));
    } catch (e) {
        return { cites: {}, alliés: ["Denzel", "Liam"], total_blocs: 0 };
    }
}

function saveMemory(data) {
    fs.writeFileSync(memoryPath, JSON.stringify(data, null, 2));
}

// --- MODULE PRINCIPAL ---
module.exports = (bot) => {
    bot.on('chat', async (username, message) => {
        if (username === bot.username) return;

        const msg = message.toLowerCase();

        // Alix ne réagit que si on l'appelle par son nom
        if (msg.startsWith('alix')) {

            // 1. ORDRE : ENREGISTRER UNE POSITION (MÉMOIRE)
            if (msg.includes('enregistre') || msg.includes('mémorise')) {
                let memory = loadMemory();
                const pos = bot.entity.position;
                const citesDisponibles = ['terrestre', 'souterraine', 'sous-marine', 'céleste', 'end', 'nether'];
                
                let citéTrouvée = citesDisponibles.find(c => msg.includes(c));
                
                if (citéTrouvée) {
                    memory.cites[citéTrouvée] = { x: Math.round(pos.x), y: Math.round(pos.y), z: Math.round(pos.z) };
                    saveMemory(memory);
                    bot.chat(`Coordonnées de la Cité ${citéTrouvée} enregistrées : ${memory.cites[citéTrouvée].x}, ${memory.cites[citéTrouvée].y}, ${memory.cites[citéTrouvée].z}`);
                } else {
                    bot.chat("De quelle cité parlez-vous, Majesté ? (Terrestre, Céleste, etc.)");
                }
                return;
            }

            // 2. ORDRE : ANALYSE INVENTAIRE & SOL
            if (msg.includes('inventaire') || msg.includes('tu as quoi')) {
                const items = bot.inventory.items().map(i => `${i.count} ${i.name}`).join(', ');
                bot.chat(items ? `Voici mon contenu : ${items}` : "Mon inventaire est vide, Majesté.");
                return;
            }

            if (msg.includes('analyse le sol')) {
                bot.scanSurroundings();
                return;
            }

            // 3. ORDRE : CONSTRUCTION & MINAGE
            const structures = {
                'terrestre': 'poste_garde_terrestre',
                'souterraine': 'pilier_souterrain',
                'sous-marine': 'bulle_sous_marine',
                'céleste': 'autel_celeste',
                'end': 'tour_elytra',
                'nether': 'bastion_nether'
            };

            for (const [key, value] of Object.entries(structures)) {
                if (msg.includes(key) && (msg.includes('construit') || msg.includes('fait'))) {
                    bot.chat(`Ordre de construction reçu pour la Cité ${key}.`);
                    bot.buildFromBlueprint(value);
                    return;
                }
            }

            if (msg.includes('creuse') || msg.includes('vide la zone')) {
                const p = bot.entity.position;
                bot.chat("Nettoyage de la zone en cours...");
                await bot.clearArea(p.x + 1, p.y, p.z + 1, p.x + 10, p.y + 5, p.z + 10);
                return;
            }

            // 4. ORDRE : OBJECTIF FINAL
            if (msg.includes('termine le jeu')) {
                bot.finishGame();
                return;
            }

            // 5. RÉPONSE GÉNÉRALE (INTELLIGENCE ARTIFICIELLE)
            try {
                const prompt = `Tu es Alix, l'assistante Pro Builder fidèle du Roi Bruno. 
                                Tu gères ses 6 cités. Ton ton est héroïque et respectueux. 
                                Réponds de manière concise. Message : ${message}`;
                
                const result = await aiModel.generateContent(prompt);
                const response = await result.response;
                bot.chat(response.text());
            } catch (err) {
                console.error(err);
                bot.chat("Désolée, mon système de pensée Gemini est indisponible.");
            }
        }
    });
};

