const fs = require('fs');
const path = require('path');

module.exports = (bot) => {
  // Fonction pour construire à partir du fichier blueprints.json
  bot.buildFromBlueprint = async (blueprintKey) => {
    const filePath = path.join(__dirname, '../data/blueprints.json');
    
    if (!fs.existsSync(filePath)) {
      bot.chat("Désolée, je ne trouve pas ma bibliothèque de plans.");
      return;
    }

    const allBlueprints = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    const blueprint = allBlueprints[blueprintKey];

    if (!blueprint) {
      bot.chat(`Le plan "${blueprintKey}" n'existe pas.`);
      return;
    }

    bot.chat(`Construction : ${blueprint.name}`);
    const startPos = bot.entity.position.clone().floored();

    for (const block of blueprint.blocks) {
      const targetPos = startPos.offset(block.x + 2, block.y, block.z);
      // Commande de force pour garantir la pose du bloc
      bot.chat(`/setblock ${targetPos.x} ${targetPos.y} ${targetPos.z} ${block.type}`);
      await new Promise(res => setTimeout(res, 150));
    }
    bot.chat("Travail terminé !");
  };

  // Fonction pour scanner le sol
  bot.scanSurroundings = () => {
    const block = bot.blockAt(bot.entity.position.offset(0, -1, 0));
    if (block) bot.chat(`Sol détecté : ${block.name}`);
  };

  // Fonction pour vider une zone (Minage)
  bot.clearArea = async (x1, y1, z1, x2, y2, z2) => {
    bot.chat(`/fill ${x1} ${y1} ${z1} ${x2} ${y2} ${z2} air`);
  };
};

