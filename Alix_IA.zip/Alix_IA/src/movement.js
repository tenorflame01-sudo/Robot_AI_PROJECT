const { pathfinder, Movements, goals } = require('mineflayer-pathfinder');

module.exports = (bot) => {
  bot.loadPlugin(pathfinder);

  bot.on('chat', (username, message) => {
    if (username === bot.username) return;
    const msg = message.toLowerCase();

    if (msg === 'alix, vient ici') {
      const target = bot.players[username]?.entity;
      if (!target) return bot.chat("Je ne vous vois pas !");
      
      const mcData = require('minecraft-data')(bot.version);
      const movements = new Movements(bot, mcData);
      
      bot.pathfinder.setMovements(movements);
      bot.pathfinder.setGoal(new goals.GoalFollow(target, 1));
      bot.chat("J'arrive, Majesté !");
    }

    if (msg === 'alix, stop') {
      bot.pathfinder.setGoal(null);
      bot.chat("Je m'arrête.");
    }
  });
};

