module.exports = {
  host: '127.0.0.1',
  port: 19132,
  username: 'Alix_IA',
  version: '1.26.0', //
  mode: 'bedrock'
};
