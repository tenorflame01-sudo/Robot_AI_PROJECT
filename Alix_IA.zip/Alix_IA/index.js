const { createAlix } = require('./src/connection.js');
const brain = require('./src/brain.js');
const combat = require('./src/combat.js');
const builder = require('./src/builder.js');
const movement = require('./src/movement.js');
const objectives = require('./src/objectives.js');

console.log("--- Lancement du Projet Alix IA ---");

const alix = createAlix();

alix.on('spawn', () => {
  console.log("Alix est opérationnelle ! Initialisation des modules...");
  
  // Activation de tous les systèmes
  builder(alix);
  movement(alix);
  objectives(alix);
  brain(alix); // Le cerveau est chargé en dernier pour que tout soit prêt
  combat(alix);
  
  console.log("Tous les systèmes sont en ligne. Prête à servir le Roi Bruno.");
});

